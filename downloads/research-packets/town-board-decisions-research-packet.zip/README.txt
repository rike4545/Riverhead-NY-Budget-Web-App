TOWN BOARD DECISIONS & VOTES

TOWN BOARD DECISIONS & VOTES RESEARCH PACKET
The meeting directory contains the published meeting records and available fiscal-impact companions. A meeting's resolution text, vote record and financial-impact statement are separate evidence types; do not infer an amount or vote from a title alone.

Campaign-finance, consent-calendar and board-election datasets are separate collections and should not be treated as Town budget appropriations. The source register identifies the underlying official records.
Riverhead Budget Live is an independent public-information project and is not affiliated with the Town of Riverhead.

PACKET CONTENTS
See packet-manifest.json for every included path, role, byte count and SHA-256 checksum. data/meta.json records the build snapshot; data/financial-reports/index.json is the source-document register.
