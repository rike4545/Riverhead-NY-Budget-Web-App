FINANCIAL HEALTH & RESERVES

FINANCIAL HEALTH & RESERVES RESEARCH PACKET
The 2025 Annual Financial Report dataset contains year-end audited results for the published funds and years. The historical budget files describe adopted spending authority, not actual expenditures. Keep those series distinct when comparing budget to results.

Fund-balance and debt measures have different scopes and dates; consult the source register and release metadata before combining them. Derived files are provided for reproducibility, not as audited statements.
Riverhead Budget Live is an independent public-information project and is not affiliated with the Town of Riverhead.

PACKET CONTENTS
See packet-manifest.json for every included path, role, byte count and SHA-256 checksum. data/meta.json records the build snapshot; data/financial-reports/index.json is the source-document register.
