2027 BUDGET SEASON

2027 BUDGET SEASON RESEARCH PACKET
This bundle keeps the Town's published budget-stage record separate from this site's independent 2027 projection. The budget-stage history is the official-stage reference; budget-2027-lines.json and budget-2027-prediction.json are model outputs, not an adopted Town budget or an official Town forecast.

Use the source register and release metadata to check document titles, dates and dataset status. The Budget Supplement records show adopted/adjusted account context; they are not interchangeable with the 2027 projection.
Riverhead Budget Live is an independent public-information project and is not affiliated with the Town of Riverhead. Verify consequential figures against the linked original Town records.

PACKET CONTENTS
See packet-manifest.json for every included path, role, byte count and SHA-256 checksum. data/meta.json records the build snapshot; data/financial-reports/index.json is the source-document register.
